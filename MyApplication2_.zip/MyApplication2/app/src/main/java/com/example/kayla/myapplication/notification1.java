package com.example.kayla.myapplication;

import android.content.Intent;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import java.util.List;
import java.util.ArrayList;
import android.widget.ArrayAdapter;
import android.widget.TimePicker;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Activity;
import android.app.AlarmManager;
import android.widget.Toast;
import java.util.Calendar;
import android.app.AlertDialog;
import android.content.DialogInterface;

public class notification1 extends ActionBarActivity {
    ArrayList<String> route;
    String station;
    Spinner spinner;
    TimePicker timePicker;
    String alarmTime;
    String depatureTime;
    private Notification mNotification;
    private NotificationManager mNotificationManager;
    private final static int NOTIFICATION_ID = 0x0001;
    private  AlarmManager mService;
    private AlarmReceiver alarm;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification1);
        Intent i = getIntent();
        //   String message = i.getStringExtra("uName");
        route = (ArrayList<String>) getIntent().getStringArrayListExtra("getRouteSelect");

        station = i.getStringExtra("getStation");
       // log.v("dsd", name);
     //   Log.v("d", route.get(0));
       // TextView text = (TextView) findViewById(R.id.text);
      //  text.setText(route.get(0));
       spinner= (Spinner) findViewById(R.id.spinner);
        List list = new ArrayList();
        list.add("5 minutes away");
        list.add("10 minutes away");
        list.add("15 minutes away");
        list.add("20 minutes away");
        list.add("25 minutes away");
        list.add("30 minutes away");
        ArrayAdapter dataAdapter = new ArrayAdapter(this,android.R.layout.simple_spinner_item, list);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(dataAdapter);
        timePicker= (TimePicker) findViewById(R.id.timePicker);

        mNotification = new Notification(R.drawable.ic_action_view_as_list,"This is a notification.",System.currentTimeMillis());
        //将使用默认的声音来提醒用户
        mNotification.defaults = Notification.DEFAULT_SOUND;
        mNotificationManager = (NotificationManager)this.getSystemService(NOTIFICATION_SERVICE);


    }

    public void buttonOnClick4(View v){
       // Button btnOk = (Button) findViewById(R.id.button);
        alarmTime= String.valueOf(spinner.getSelectedItem());
         depatureTime = String.valueOf(timePicker.getCurrentHour()+" "+timePicker.getCurrentMinute());
        alarm = new AlarmReceiver();


        //  showNotification();

        startActivity(new Intent(getApplicationContext(),done1.class));

     /*   Intent mIntent = new Intent(notification1.this,MainActivity.class);
        //这里需要设置Intent.FLAG_ACTIVITY_NEW_TASK属性
        mIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent mContentIntent =PendingIntent.getActivity(notification1.this,0, mIntent, 0);
        //这里必需要用setLatestEventInfo(上下文,标题,内容,PendingIntent)不然会报错.
        mNotification.setLatestEventInfo(notification1.this, "10086", "您的当前话费不足,请充值.哈哈~", mContentIntent);
        //这里发送通知(消息ID,通知对象)
        mNotificationManager.notify(NOTIFICATION_ID, mNotification);*/
      /*  Intent intent = new Intent(notification1.this, AlarmReceiver.class);
        PendingIntent sender = PendingIntent.getBroadcast(notification1.this, 0, intent, 0);

// 过10s 执行这个闹铃
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(System.currentTimeMillis());
        calendar.add(Calendar.SECOND, 10);

        AlarmManager manager = (AlarmManager)getSystemService(ALARM_SERVICE);
        manager.set(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), sender);*/
      //  Context context = this.getApplicationContext();
     //   if(alarm != null){
     //       alarm.setOnetimeTimer(context);
     //   }else{
      //      Toast.makeText(context, "Alarm is null", Toast.LENGTH_SHORT).show();

       // }
      //  Calendar cal = Calendar.getInstance();
      //  cal.add(Calendar.SECOND, 5);

        //Create a new PendingIntent and add it to the AlarmManager
      //  Intent intent = new Intent(this, AlarmReceiver.class);
      //  PendingIntent pendingIntent = PendingIntent.getActivity(this,
       //         12345, intent, PendingIntent.FLAG_CANCEL_CURRENT);
      //  AlarmManager am =
      //  //        (AlarmManager)getSystemService(Activity.ALARM_SERVICE);
      //  am.set(AlarmManager.RTC_WAKEUP, cal.getTimeInMillis(),
        //        pendingIntent);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_notification1, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    public void set(int type, long triggerAtMillis, PendingIntent operation) {

            mService.set(type, triggerAtMillis, operation);

    }

    public void setTime(View view) {
        // Do something in response to button

        AlertDialog alertDialog = new AlertDialog.Builder(this).create();
        alertDialog.setTitle("You have set");
        alertDialog.setMessage("NOTIFICATION");
        alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
// here you can add functions
            
            }
        });
        alertDialog.setIcon(R.drawable.ic_action_view_as_list);
        alertDialog.show();
    }




}
