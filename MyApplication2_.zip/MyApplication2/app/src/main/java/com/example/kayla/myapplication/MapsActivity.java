package com.example.kayla.myapplication;

import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.*;
import com.google.android.gms.maps.GoogleMap.OnMarkerClickListener;
import java.util.ArrayList;
public class MapsActivity extends FragmentActivity  {

    public Marker marker1 ;
  // List<Marker> markers = new ArrayList<Marker>();
    private GoogleMap mMap; // Might be null if Google Play services APK is not available.
    ArrayList<String> list = new ArrayList<String>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        setUpMapIfNeeded();
        list.add("Item1");

        list.add("Item2");

        list.add("Item3"); // it will add Item3 to the third position of

        // array list

        list.add("Item4");


    }

    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #mMap} is not null.
     * <p/>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p/>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (mMap == null) {
            // Try to obtain the map from the SupportMapFragment.
            mMap = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (mMap != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera. In this case, we
     * just add a marker near Africa.
     * <p/>
     * This should only be called once and when we are sure that {@link #mMap} is not null.
     */
    private void setUpMap() {
    //    mMap.addMarker(new MarkerOptions().position(new LatLng(29, -82)).title("Marker1"));
      //  marker1 = new MarkerOptions().position(new LatLng(29, -82)).title("Marker1");

        //marker1[0]=mMap.addMarker(new MarkerOptions().position(new LatLng(29, -82)).title("Marker1"));
       // marker1.setTitle("Marker1");
       // mMap.addMarker(marker1[0]);
          marker1= mMap.addMarker(new MarkerOptions()
                .position(new LatLng(29,-82))
                .title("Station name")
                .snippet("Route Number: 4,137,400"));
        /* marker1[0][1] = mMap.addMarker(new MarkerOptions()
                .position(new LatLng(29.23,-82.33))
                .title("TTT")
                .snippet("Route Number: 4,137,400"));*/
      /*  mMap.setOnMarkerClickListener(new OnMarkerClickListener()
        {

            @Override
            public boolean onMarkerClick(Marker arg0) {
               // if(arg0.getTitle().equals("Melbourne")) // if marker source is clicked
                   // Toast.makeText(MainActivity.this, arg0.getTitle(), Toast.LENGTH_SHORT).show();// display toast
               startActivity(new Intent(getApplicationContext(),MainActivity3.class));
                return true;
            }

        });*/
mMap.setOnInfoWindowClickListener(new GoogleMap.OnInfoWindowClickListener() {
    @Override
    public void onInfoWindowClick(Marker marker) {
        Intent i = new Intent(getApplicationContext(),MainActivity4.class);
     //   Bundle routeNum = new Bundle();
     //   routeNum.putSerializable("Route", new int[]{15,2,12,2});
      //  routeNum.putSerializable("ad",new String[]{"5","6"});
    //    i.putExtra("getRoute", routeNum);


        i.putExtra("getPosition",marker.getPosition());
        i.putExtra("getStation", marker.getTitle());
       // i.putExtra("getRoute",route);
        i.putStringArrayListExtra("getRoute", list);
        startActivity (i);

       // startActivity(new Intent(getApplicationContext(),MainActivity3.class));
    }
});
    }
}
